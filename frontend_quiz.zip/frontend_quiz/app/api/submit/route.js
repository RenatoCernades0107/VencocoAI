export async function POST(request) {
    try {
      const data = await request.json();
      const { question1, question2, question3 } = data;
  
      // Process the data or save it to a database
      console.log("Received form data:", { question1, question2, question3 });
  
      return new Response(JSON.stringify({ message: "Form data received" }), {
        status: 200,
        headers: {
          "Content-Type": "application/json",
        },
      });
    } catch (error) {
      return new Response(JSON.stringify({ message: "Error processing data" }), {
        status: 500,
        headers: {
          "Content-Type": "application/json",
        },
      });
    }
  }
  