"use client";

import { ChangeEvent, useState } from "react";
import Image from "next/image";

export default function Home() {
  const [step, setStep] = useState(0);
  const [photo, setPhoto] = useState<string | null>(null);
  const [apiResponse, setApiResponse] = useState<any>(null); // API response for skin analysis

  const handlePhotoUpload = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = async () => {
        setPhoto(reader.result as string);
        // Here you would send the image to your API and get the response
        // Example:
        // const response = await fetch("/api/analyze", { method: "POST", body: formData });
        // const data = await response.json();
        // setApiResponse(data);
      };
      reader.readAsDataURL(file);
    }
  };

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  return (
    <div className="grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 pb-20 gap-16 sm:p-20 font-[family-name:var(--font-geist-sans)]">
      <main className="flex flex-col gap-8 row-start-2 items-center sm:items-start">
        <Image
          className="dark:invert"
          src="https://nextjs.org/icons/next.svg"
          alt="Next.js logo"
          width={180}
          height={38}
          priority
        />
        
        {step === 0 && (
          <div className="flex flex-col gap-4 items-center text-center">
            <h1 className="text-2xl font-bold">Welcome to the Facial Analysis!</h1>
            <p className="text-md text-gray-600">
              Please upload a photo of your face for analysis.
            </p>
            <input type="file" accept="image/*" onChange={handlePhotoUpload} />
            {photo && <img src={photo} alt="Uploaded" className="mt-4" />}
            <button onClick={nextStep} className="bg-blue-500 text-white px-4 py-2 rounded mt-4">
              Next
            </button>
          </div>
        )}

        {/* Add your API response handling logic here */}
      </main>
      
      <footer className="row-start-3 flex gap-6 flex-wrap items-center justify-center">
        {/* Add your footer links here */}
      </footer>
    </div>
  );
}
