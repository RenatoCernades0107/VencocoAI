"use client";

import { ChangeEvent, useState } from "react";
import Image from "next/image";

// Define user data as a JSON string
const userJson = `
{
  "skinType": "Normal",
  "skinConcerns": {
    "spots": false,
    "wrinkles": false,
    "moisture": true,
    "redness": false,
    "oiliness": true,
    "acne": false,
    "texture": false,
    "darkCircles": false,
    "eyeBags": false,
    "skinFirmness": true,
    "droopyUpperEyelid": false,
    "droopyLowerEyelid": false,
    "radiance": false,
    "visiblePores": true
  }
}
`;

// Parse the JSON string into an object
const user = JSON.parse(userJson);

export default function BeautyQuestionnaire() {
  const [step, setStep] = useState(0);
  const [formData, setFormData] = useState({
    budgetSkincare: "",
    singleProductBudget: "",
    skincareFrequency: "",
    consultExperts: "",
    skinType: user.skinType,
    specificQuestions: "",
    naturalProducts: "",
    specificIngredients: "",
  });

  const [checkedSkinConcerns, setCheckedSkinConcerns] = useState(user.skinConcerns);

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  const handleChange = (e: ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleCheckboxChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    setCheckedSkinConcerns((prev: Object) => ({ ...prev, [name]: checked }));
  };

  const handleSubmit = async () => {
    try {
      const selectedSkinConcerns = Object.fromEntries(
        Object.entries(checkedSkinConcerns).filter(([_, value]) => value)
      );

      const dataToSend = { ...formData, skinConcerns: selectedSkinConcerns };

      // Print the JSON object to the console
      console.log("Data being sent:", JSON.stringify(dataToSend, null, 2));

      const response = await fetch("/api/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(dataToSend),
      });
      
      if (response.ok) {
        alert("Form submitted successfully!");
      } else {
        alert("Something went wrong, please try again.");
      }
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };  

  return (
    <div className="grid grid-rows-[20px_1fr_20px] items-center justify-items-center min-h-screen p-8 pb-20 gap-16 sm:p-20 font-[var(--font-geist-sans)] bg-background">
      <main className="flex flex-col gap-8 row-start-2 items-center sm:items-start">
      <Image
        className="dark:invert"
        src="/sombras3.png"
        alt="Next.js logo"
        width={180}
        height={38}
        priority
        />

        {step === 0 && (
          <div className="flex flex-col gap-4 items-center text-center">
            <h1 className="text-3xl font-bold text-red-500">Welcome to the Beauty Questionnaire!</h1>
            <p className="text-md text-stone-500">
              Discover the best skincare routine tailored for you by answering a few simple questions.
            </p>
            <button 
              onClick={nextStep} 
              className="bg-red-500 text-white px-6 py-2 rounded shadow-md hover:bg-stone-500 transition duration-200 mt-4"
            >
              Start
            </button>
          </div>
        )}

        {step === 1 && (
          <div className="flex flex-col gap-4 p-4 border rounded-lg shadow-md bg-white">
            <h2 className="text-2xl font-bold text-red-500">Section 1: Spending Expectations</h2>
            <label className="text-stone-500">What is your monthly budget for skincare products?</label>
            <select
              name="budgetSkincare"
              value={formData.budgetSkincare}
              onChange={handleChange}
              className="border rounded p-2 mt-2"
            >
              <option value="" disabled>Select your budget</option>
              <option value="Under $20">Under $20</option>
              <option value="$20 - $50">$20 - $50</option>
              <option value="$50 - $100">$50 - $100</option>
              <option value="Over $100">Over $100</option>
            </select>
            <label className="text-stone-500 mt-4">How much are you willing to spend on a single skincare product?</label>
            <select
              name="singleProductBudget"
              value={formData.singleProductBudget}
              onChange={handleChange}
              className="border rounded p-2 mt-2"
            >
              <option value="" disabled>Select your budget</option>
              <option value="Under $20">Under $20</option>
              <option value="$20 - $50">$20 - $50</option>
              <option value="$50 - $100">$50 - $100</option>
              <option value="Over $100">Over $100</option>
            </select>
            <button 
              onClick={nextStep} 
              className="bg-red-500 text-white px-6 py-2 rounded shadow-md hover:bg-stone-500 transition duration-200 mt-4"
            >
              Next
            </button>
          </div>
        )}

        {step === 2 && (
          <div className="flex flex-col gap-4 p-4 border rounded-lg shadow-md bg-white">
            <h2 className="text-2xl font-bold text-red-500">Section 2: Familiarity with Beauty Products</h2>
            <label className="text-stone-500">How often do you use skincare products?</label>
            <select
              name="skincareFrequency"
              value={formData.skincareFrequency}
              onChange={handleChange}
              className="border rounded p-2 mt-2"
            >
              <option value="" disabled>Select frequency</option>
              <option value="Daily">Daily</option>
              <option value="A few times a week">A few times a week</option>
              <option value="Rarely">Rarely</option>
              <option value="Never">Never</option>
            </select>
            <label className="text-stone-500 mt-4">Do you consult skincare experts (dermatologists, aestheticians) for product recommendations?</label>
            <select
              name="consultExperts"
              value={formData.consultExperts}
              onChange={handleChange}
              className="border rounded p-2 mt-2"
            >
              <option value="" disabled>Select option</option>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
            <button 
              onClick={nextStep} 
              className="bg-red-500 text-white px-6 py-2 rounded shadow-md hover:bg-stone-500 transition duration-200 mt-4"
            >
              Next
            </button>
          </div>
        )}

        {step === 3 && (
          <div className="flex flex-col gap-4 p-4 border rounded-lg shadow-md bg-white">
            <h2 className="text-2xl font-bold text-red-500">Section 3: Skin Concerns</h2>
            <p className="text-stone-500">Please indicate the skin concerns you would like to address:</p>
            {Object.keys(checkedSkinConcerns).map((concern) => (
              <div key={concern} className="flex items-center">
                <input
                  type="checkbox"
                  name={concern}
                  checked={checkedSkinConcerns[concern] || false}
                  onChange={handleCheckboxChange}
                  className="mr-2"
                />
                <label className="text-stone-500">{concern.charAt(0).toUpperCase() + concern.slice(1).replace(/([A-Z])/g, ' $1')}</label>
              </div>
            ))}
            <button 
              onClick={nextStep} 
              className="bg-red-500 text-white px-6 py-2 rounded shadow-md hover:bg-stone-500 transition duration-200 mt-4"
            >
              Next
            </button>
          </div>
        )}

        {step === 4 && (
          <div className="flex flex-col gap-4 p-4 border rounded-lg shadow-md bg-white">
            <h2 className="text-2xl font-bold text-red-500">Section 4: Specific Questions for Skin Types</h2>
            <h3 className="text-xl font-semibold text-stone-500">For {formData.skinType} Skin:</h3>
            <label className="text-stone-500">Do you prefer natural products?</label>
            <select
              name="naturalProducts"
              value={formData.naturalProducts}
              onChange={handleChange}
              className="border rounded p-2 mt-2"
            >
              <option value="" disabled>Select option</option>
              <option value="Yes">Yes</option>
              <option value="No">No</option>
            </select>
            <label className="text-stone-500 mt-4">Any specific ingredients you want to avoid?</label>
            <input
              type="text"
              name="specificIngredients"
              value={formData.specificIngredients}
              onChange={handleChange}
              className="border rounded p-2 mt-2"
            />
            <button 
              onClick={handleSubmit} 
              className="bg-red-500 text-white px-6 py-2 rounded shadow-md hover:bg-stone-500 transition duration-200 mt-4"
            >
              Submit
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
